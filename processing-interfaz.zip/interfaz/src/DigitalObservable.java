package cc.digitalobservable;

import java.util.Observable;

public class DigitalObservable extends Observable {
    public void change() {
      setChanged();
      notifyObservers();
    }
  }