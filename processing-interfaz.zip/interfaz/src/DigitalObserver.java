package cc.digitalobserver;

import cc.interfaz.*;
import java.util.Observer;
import java.util.Observable;

public class DigitalObserver implements Observer {
  Interfaz.DIGITAL dg;

  public void setInstance(Interfaz.DIGITAL _dg) {
    dg = _dg;
  }
  public void update(Observable obs, Object obj) {
    dg.digitalEvent();
  }    
}