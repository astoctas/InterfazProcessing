package cc.i2cplugin.sht11;

import cc.i2cplugin.*;

public class SHT11 implements I2CPlugin {
    
}