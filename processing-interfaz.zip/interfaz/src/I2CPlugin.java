package cc.i2cplugin;

import processing.core.PApplet;

public interface I2CPlugin {

}